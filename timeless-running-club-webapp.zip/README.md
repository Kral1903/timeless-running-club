# Timeless Running Club – erste Web-App

## Enthalten
- Responsives Design mit Bergen und Laufweg
- Deutsch, Englisch und Türkisch
- GPS-Aufzeichnung mit Distanz, Dauer, durchschnittlicher Pace und vereinfachter Routen-Vorschau
- 30-Tage-Anfänger-Challenge mit lokal gespeicherten Häkchen
- Upload-Vorschau für dein bestehendes Logo
- Einfacher Offline-Cache als Startpunkt für eine installierbare Web-App

## Wichtige Hinweise
- GPS funktioniert nur in einem sicheren Kontext: HTTPS oder localhost. GitHub Pages stellt HTTPS bereit.
- Diese erste Version speichert Trainingsdaten nicht dauerhaft und sendet Standortdaten nicht an einen Server. Fortschritts-Häkchen und Logo werden lokal im Browser gespeichert.
- Die Routen-Vorschau ist eine einfache Linienzeichnung, keine Straßenkarte. Die GPS-Aufzeichnung kann durch Empfang, Geräte und Browser beeinflusst werden.
- Vor öffentlicher Nutzung bitte Datenschutzinformationen ergänzen und die App auf mehreren Geräten testen. Dies ist kein medizinischer Trainingsplan.
- Das hochgeladene Logo wird in dieser Version nur lokal angezeigt. Für alle Nutzer sichtbar muss die Bilddatei in das Repository hochgeladen und die HTML-Datei entsprechend angepasst werden.

## Veröffentlichung über GitHub Pages (kostenlos)
1. Öffne https://github.com/ und melde dich an oder erstelle ein Konto.
2. Wähle oben rechts **+ → New repository**.
3. Repository-Name: `timeless-running-club`; stelle es auf **Public** und erstelle es.
4. Öffne **Add file → Upload files** und lade `index.html`, `manifest.json` und `sw.js` aus diesem ZIP hoch. Lade nicht nur die ZIP-Datei hoch, sondern die drei einzelnen Dateien.
5. Klicke auf **Commit changes**.
6. Öffne **Settings → Pages**.
7. Unter **Build and deployment** wähle **Deploy from a branch**.
8. Wähle Branch `main` und Ordner `/(root)`, dann **Save**.
9. Warte einige Minuten. GitHub zeigt anschließend deine veröffentlichte URL an, meist `https://DEIN-BENUTZERNAME.github.io/timeless-running-club/`.
10. Öffne den Link auf deinem Handy und erlaube Standortzugriff, wenn du **Lauf starten** drückst.
11. Teste zuerst im Freien. Wenn GPS nicht funktioniert, prüfe Standortberechtigungen und ob die URL mit `https://` beginnt.

## Bestehendes Logo
Für ein Logo, das allen Besuchern angezeigt wird:
1. Benenne deine Logo-Datei `logo.png`.
2. Lade sie in das Repository hoch.
3. In `index.html` kann das Logo in den Header eingebunden werden; sag mir Bescheid, wenn du die Datei hochlädst, dann passe ich den Code passend an.

## Kosten
GitHub Pages kann für öffentliche Repositories im kostenlosen Tarif genutzt werden. Ein eigener Domainname ist optional und kann Geld kosten. Google Play Store-Veröffentlichung ist nicht Teil dieses Projekts.
